function varargout = prediksi_cuaca(varargin)
% PREDIKSI_CUACA MATLAB code for prediksi_cuaca.fig
%      PREDIKSI_CUACA, by itself, creates a new PREDIKSI_CUACA or raises the existing
%      singleton*.
%
%      H = PREDIKSI_CUACA returns the handle to a new PREDIKSI_CUACA or the handle to
%      the existing singleton*.
%
%      PREDIKSI_CUACA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PREDIKSI_CUACA.M with the given input arguments.
%
%      PREDIKSI_CUACA('Property','Value',...) creates a new PREDIKSI_CUACA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before prediksi_cuaca_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to prediksi_cuaca_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help prediksi_cuaca

% Last Modified by GUIDE v2.5 22-May-2023 20:05:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @prediksi_cuaca_OpeningFcn, ...
                   'gui_OutputFcn',  @prediksi_cuaca_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before prediksi_cuaca is made visible.
function prediksi_cuaca_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to prediksi_cuaca (see VARARGIN)

% Choose default command line output for prediksi_cuaca
handles.output = hObject;
a = imread('smallKobo.jpg');
axes(handles.axes2);
imshow(a);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes prediksi_cuaca wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = prediksi_cuaca_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in push_tampil.
function push_tampil_Callback(hObject, eventdata, handles)
% hObject    handle to push_tampil (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA);
opts = detectImportOptions('seattle-weather.csv');
opts.SelectedVariableNames = (2:5);
data = readmatrix('seattle-weather.csv', opts);
set(handles.uitable1,'data',data);


% --- Executes on button press in push_hasil.
function push_hasil_Callback(hObject, eventdata, handles)
% hObject    handle to push_hasil (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prec = str2double(get(handles.setPrecip, 'string'));
wind = str2double(get(handles.setWind, 'string'));
max  = str2double(get(handles.setTempMax, 'string'));
min  = str2double(get(handles.setTempMin, 'string'));

sample=[prec max min wind];
opts = detectImportOptions('seattle-weather.csv');
opts.SelectedVariableNames = (2:5);
training = readmatrix('seattle-weather.csv', opts);

opts = detectImportOptions('seattle-weather.csv');
opts.SelectedVariableNames = (6);
grup = readmatrix('seattle-weather.csv', opts);

class = fitcknn(training, grup, 'NumNeighbors', 3);
klasifikasi = predict(class, sample);

set(handles.get_result, 'string', klasifikasi);

% --- Executes on button press in push_reset.
function push_reset_Callback(hObject, eventdata, handles)
% hObject    handle to push_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = '';
set(handles.setPrecip, 'string', a);
set(handles.setWind, 'string', a);
set(handles.setTempMax, 'string', a);
set(handles.setTempMin, 'string', a);
set(handles.get_result, 'string', a);


function get_result_Callback(hObject, eventdata, handles)
% hObject    handle to get_result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of get_result as text
%        str2double(get(hObject,'String')) returns contents of get_result as a double


% --- Executes during object creation, after setting all properties.
function get_result_CreateFcn(hObject, eventdata, handles)
% hObject    handle to get_result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setPrecip_Callback(hObject, eventdata, handles)
% hObject    handle to setPrecip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setPrecip as text
%        str2double(get(hObject,'String')) returns contents of setPrecip as a double


% --- Executes during object creation, after setting all properties.
function setPrecip_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setPrecip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setTempMax_Callback(hObject, eventdata, handles)
% hObject    handle to setTempMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setTempMax as text
%        str2double(get(hObject,'String')) returns contents of setTempMax as a double


% --- Executes during object creation, after setting all properties.
function setTempMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setTempMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setWind_Callback(hObject, eventdata, handles)
% hObject    handle to setWind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setWind as text
%        str2double(get(hObject,'String')) returns contents of setWind as a double


% --- Executes during object creation, after setting all properties.
function setWind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setWind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setTempMin_Callback(hObject, eventdata, handles)
% hObject    handle to setTempMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setTempMin as text
%        str2double(get(hObject,'String')) returns contents of setTempMin as a double


% --- Executes during object creation, after setting all properties.
function setTempMin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setTempMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function setWeather_Callback(hObject, eventdata, handles)
% hObject    handle to setWeather (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of setWeather as text
%        str2double(get(hObject,'String')) returns contents of setWeather as a double


% --- Executes during object creation, after setting all properties.
function setWeather_CreateFcn(hObject, eventdata, handles)
% hObject    handle to setWeather (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in out.
function out_Callback(hObject, eventdata, handles)
% hObject    handle to out (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closereq(); 

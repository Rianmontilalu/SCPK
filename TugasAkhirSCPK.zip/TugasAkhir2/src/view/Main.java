/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String args[]) {
        LoginForm l = new LoginForm();
        l.setVisible(true);
    }
}
